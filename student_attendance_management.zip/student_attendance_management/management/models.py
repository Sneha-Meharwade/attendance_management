from django.db import models
from .import models


# Create your models here.
class students(models.Model):
    name=models.CharField(max_length=30)
    roll_no=models.IntegerField(primary_key=True)
    standard=models.IntegerField(max_length=12,default='10th')
    phonenumber=models.IntegerField(max_length=30)
    address=models.CharField(max_length=30)
