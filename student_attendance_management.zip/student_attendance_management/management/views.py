
from django.shortcuts import render,redirect,HttpResponse
from django.db.models import Q
from django.contrib import messages
from models import *



# Create your views here.
def add(request):
    if request.method == 'POST':
        a=request.POST.get('name')
        b=request.POST.get('roll_no')
        c=request.POST.get('standard')
        d=request.POST.get('phonenumber')
        e=request.POST.get('address')
        f= students(name=a,address=e,standard=c,phonenumber=d,roll_no=b)
        f.save()
    else:
        return render(request,'students.html',context={})
    return HttpResponse('Data is inserted sucessfully')
       
    
def view(request):
    management=students.objects.all()
    return render(request,'show_students.html',context={'manage':management})

def delete(request, roll_no):
    a = students.objects.get(roll_no=roll_no)
    a.delete()
    messages.success(request, "Student details has been deleted successfully")
    return HttpResponse('Student details has been deleted successfully')

