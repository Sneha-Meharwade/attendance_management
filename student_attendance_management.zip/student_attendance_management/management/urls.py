from django.contrib import admin
from management import views
from django.urls import path,include

urlpatterns = [
    path('', include('management.urls')),
    path('add-student/',views.add,name='add'),
]